﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace AskForDataAndDisplay
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // remember to add the line "using static System.Console;" above the namespace

            // this line will display an instruction line on the console
            // and then will wait for user to enter a number and press the
            // Enter key.
            WriteLine("Please enter a number.  It can have decimal places.");
            

            // this line will take the number that was entered,
            // convert it to a double  
            // and assign the value to enteredNum
            double enteredNum = Convert.ToDouble(ReadLine());


            // this line will add 10 to enteredNum
            enteredNum = enteredNum + 10;


            // this line will display the increased enteredNum in a format that
            // has three decimal places
            WriteLine("The increased number is: " + enteredNum.ToString("F3"));


            // this line will pause the console so you can see the output
            // when the user presses the Enter key, the program will end
            ReadLine();
        }
    }
}
